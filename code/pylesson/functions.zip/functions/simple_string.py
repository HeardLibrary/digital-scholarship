def concatenation(firstString, secondString):
    answer = firstString + secondString
    return answer

def findLength(string):
    return len(string)
