def addition(firstNumber, secondNumber):
    answer = firstNumber + secondNumber
    return answer

def subtraction(firstNumber, secondNumber):
    answer = firstNumber - secondNumber
    return answer

def multiplication(firstNumber, secondNumber):
    answer = firstNumber * secondNumber
    return answer

def division(firstNumber, secondNumber):
    answer = firstNumber / secondNumber
    return answer
